#!/bin/sh

echo "Regenerating build files..."
autoreconf -fi -Im4

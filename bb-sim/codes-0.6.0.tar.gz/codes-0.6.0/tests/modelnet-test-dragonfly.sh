#!/bin/bash

tests/modelnet-test --sync=1 -- tests/conf/modelnet-test-dragonfly.conf



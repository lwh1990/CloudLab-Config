#!/bin/bash

src/network-workloads/model-net-synthetic-custom-dfly --sync=1 --num_messages=1 -- src/network-workloads/conf/dragonfly-custom/modelnet-test-dragonfly-1728-nodes.conf







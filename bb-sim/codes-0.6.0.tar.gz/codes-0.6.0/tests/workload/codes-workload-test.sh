#!/bin/bash

tests/workload/codes-workload-test --sync=1 $srcdir/tests/workload/codes-workload-test.conf

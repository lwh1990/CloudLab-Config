#!/bin/bash

tests/lp-io-test --sync=1

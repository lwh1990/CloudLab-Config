/* Copyright (C) 2011 Omnibond, LLC
   Client tests - file info declarations */

#ifndef __INFO_H
#define __INFO_H

#include "test-support.h"

int file_time(global_options *options, int fatal);
int volume_space(global_options *options, int fatal);

#endif
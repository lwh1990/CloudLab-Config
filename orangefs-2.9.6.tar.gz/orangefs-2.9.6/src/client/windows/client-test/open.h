/* Copyright (C) 2001 Omnibond, LLC
   Client test - open file declarations */

#ifndef __OPEN_H
#define __OPEN_H

#include "test-support.h"

int open_file(global_options *options, int fatal);

#endif
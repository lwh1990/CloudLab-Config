#!/bin/sh
libtoolize &&
autoreconf -i

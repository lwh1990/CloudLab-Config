cd $(dirname $0)
. setenv
rm -rf ${ORANGEFS_STORAGE_DIR}/*

# STOP
killall pvfs2-server

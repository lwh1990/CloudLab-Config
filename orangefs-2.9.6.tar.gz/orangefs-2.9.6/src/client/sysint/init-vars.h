#ifndef __INIT_VARS_H
#define __INIT_VARS_H

extern int relatime_timeout;

#endif
